package assignment02;

public class Cell {
    public int counter;
    public Player player;
    
    public Cell(int counter, Player player) {
        this.counter = counter;
        this.player = player;
    }
    
    
    
    
}
