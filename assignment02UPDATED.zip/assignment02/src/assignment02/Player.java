
package assignment02;

public enum Player {
    RED, 
    BLUE,
    NOONE;
}
//public enum Player {
//    
//    RED(0),
//    BLUE(0),
//    NOONE(0);
//    
//    private int score;
//    Player(int newScore) { this.score = newScore;}
//    public int getScore() { return this.score; }
//    public void setScore(int newScore) { this.score = newScore; }
//}

//public enum Ids {
//    OPEN(100), CLOSE(200);
//
//    private final int id;
//    Ids(int id) { this.id = id; }
//    public int getValue() { return id; }
//}
