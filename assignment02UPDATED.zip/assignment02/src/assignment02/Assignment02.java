package assignment02;

public class Assignment02 {

    public static void main(String[] args) {
        MenuWindow menuWindow = new MenuWindow();
        menuWindow.setVisible(true);
    }
    
}
