package assignment01;


import java.util.ArrayList;

public abstract class Polygon {

    private Point center;
    private double length;

    public Polygon(double x, double y, double length) {
        if(length <= 0) { throw new IllegalArgumentException("Length (radius) cannot be negative or 0"); } 
        this.center = new Point(x,y);
        this.length = length;
    }

    public Point getCenter() {
        return center;
    }

    public double getLength() {
        return length;
    }

    public void setCenter(Point center) {
        this.center = center;
    }

    public void setLength(double length) {
        this.length = length;
    }
    
    public abstract ArrayList<Point> getCoordinates();

}
