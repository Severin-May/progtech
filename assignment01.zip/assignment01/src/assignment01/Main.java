package assignment01;

import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.io.File;
import java.util.Scanner;
import java.util.*;

public class Main {

    public static void main(String[] args) {
        
        FileRead database = new FileRead();
        
        try {
            database.populating("data1.txt"); 
        //empty.txt for empty file - works fine
        //invalid.txt when given figure is not S,C,H,T - works fine 
        //negative.txt when length is negative or 0 - works fine
        //1input.txt when there is only one shape, circle - works fine
        //1hexa.txt when there is only one shape, hexagon - works fine
        //data.txt usual case - works fine
        //data1.txt
        } catch (FileNotFoundException ex) {
            System.out.println("File not found!");
            System.exit(-1);
        } catch (InvalidInputException ex) {
            System.out.println("Invalid input!");
            System.exit(-1);
        }
        System.out.print(database.findBox());
        //System.out.print(database.toString());
    }
        
//        Polygon circle = new Circle(0,0, 2);
//        Polygon square = new Square(2,1,4);
//        Polygon triangle = new Triangle(2,2,3);
//        Polygon hexa = new Hexagon(1,3,3);
//        
//        ArrayList<Polygon> shapes = new ArrayList<Polygon>();
//        
//        shapes.add(circle);
//        shapes.add(square);
//        shapes.add(triangle);
//        shapes.add(hexa);
//        
//        ArrayList<Point> coordinates = new ArrayList<>();
//        
//        coordinates.addAll(circle.getCoordinates());
//        coordinates.addAll(square.getCoordinates());
//        coordinates.addAll(triangle.getCoordinates());
//        coordinates.addAll(hexa.getCoordinates());
//        
//        for(Point p: coordinates) {
//            System.out.println(p.toString());
//        }
    
        
}
    

/*
Fill a collection with several regular shapes (circle, regular triangle, square, regular hexagon).
Determine the smallest bounding box, which contains all the shapes, and its sides parallel with
an x or y axis.
Each shape can be represented by its center and side length (or radius), if we assume that one
side of the polygons are parallel with x axis, and its nodes lies on or above this side.
Load and create the shapes from a text file. The first line of the file contains the number of the
shapes, and each following line contain a shape. The first character will identify the type of the
shape, which is followed by the center coordinate and the side length or radius.
Manage the shapes uniformly, so derive them from the same super class.
*/

